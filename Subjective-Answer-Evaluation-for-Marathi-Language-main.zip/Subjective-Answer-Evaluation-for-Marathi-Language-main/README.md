# Subjective-Answer-Evaluation-for-Marathi-Language
You have to install some libraries
1. pip install numpy
2. pip install math
3. pip install fuzzywuzzy
4. pip install requests
5. pip install easyocr
6. pip install pytesseract
7. pip install tesseract-ocr
8. pip install Image

To run this type "app.py' and it will run on http://127.0.0.5000
